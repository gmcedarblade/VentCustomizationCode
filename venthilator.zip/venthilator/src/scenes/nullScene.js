var NullScene = function(game, stage)
{
  var self = this;

  var canv = stage.drawCanv;
  var canvas = canv.canvas;
  var ctx = canv.context;

  self.ready = function()
  {

  };

  self.tick = function()
  {

  };

  self.draw = function()
  {

  };

  self.cleanup = function()
  {

  };
};
